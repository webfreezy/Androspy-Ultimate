﻿namespace SV
{
    partial class Telefon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Telefon));
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
            this.button14 = new MetroFramework.Controls.MetroTile();
            this.button10 = new MetroFramework.Controls.MetroTile();
            this.button11 = new MetroFramework.Controls.MetroTile();
            this.button12 = new MetroFramework.Controls.MetroTile();
            this.button7 = new MetroFramework.Controls.MetroTile();
            this.button8 = new MetroFramework.Controls.MetroTile();
            this.button9 = new MetroFramework.Controls.MetroTile();
            this.button4 = new MetroFramework.Controls.MetroTile();
            this.button5 = new MetroFramework.Controls.MetroTile();
            this.button6 = new MetroFramework.Controls.MetroTile();
            this.button3 = new MetroFramework.Controls.MetroTile();
            this.button2 = new MetroFramework.Controls.MetroTile();
            this.button1 = new MetroFramework.Controls.MetroTile();
            this.button13 = new MetroFramework.Controls.MetroTile();
            this.textBox1 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.button15 = new MetroFramework.Controls.MetroTile();
            this.textBox3 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.textBox2 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage3 = new MetroFramework.Controls.MetroTabPage();
            this.textBox4 = new System.Windows.Forms.RichTextBox();
            this.button17 = new MetroFramework.Controls.MetroTile();
            this.button16 = new MetroFramework.Controls.MetroTile();
            this.metroTabPage4 = new MetroFramework.Controls.MetroTabPage();
            this.label4 = new MetroFramework.Controls.MetroLabel();
            this.button19 = new MetroFramework.Controls.MetroTile();
            this.button20 = new MetroFramework.Controls.MetroTile();
            this.button18 = new MetroFramework.Controls.MetroTile();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.metroTabControl1.SuspendLayout();
            this.metroTabPage1.SuspendLayout();
            this.metroTabPage2.SuspendLayout();
            this.metroTabPage3.SuspendLayout();
            this.metroTabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Controls.Add(this.metroTabPage1);
            this.metroTabControl1.Controls.Add(this.metroTabPage2);
            this.metroTabControl1.Controls.Add(this.metroTabPage3);
            this.metroTabControl1.Controls.Add(this.metroTabPage4);
            this.metroTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroTabControl1.Location = new System.Drawing.Point(20, 60);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 0;
            this.metroTabControl1.Size = new System.Drawing.Size(529, 415);
            this.metroTabControl1.TabIndex = 1;
            this.metroTabControl1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabControl1.UseSelectable = true;
            // 
            // metroTabPage1
            // 
            this.metroTabPage1.Controls.Add(this.button14);
            this.metroTabPage1.Controls.Add(this.button10);
            this.metroTabPage1.Controls.Add(this.button11);
            this.metroTabPage1.Controls.Add(this.button12);
            this.metroTabPage1.Controls.Add(this.button7);
            this.metroTabPage1.Controls.Add(this.button8);
            this.metroTabPage1.Controls.Add(this.button9);
            this.metroTabPage1.Controls.Add(this.button4);
            this.metroTabPage1.Controls.Add(this.button5);
            this.metroTabPage1.Controls.Add(this.button6);
            this.metroTabPage1.Controls.Add(this.button3);
            this.metroTabPage1.Controls.Add(this.button2);
            this.metroTabPage1.Controls.Add(this.button1);
            this.metroTabPage1.Controls.Add(this.button13);
            this.metroTabPage1.Controls.Add(this.textBox1);
            this.metroTabPage1.Controls.Add(this.metroLabel1);
            this.metroTabPage1.HorizontalScrollbarBarColor = true;
            this.metroTabPage1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.HorizontalScrollbarSize = 10;
            this.metroTabPage1.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage1.Name = "metroTabPage1";
            this.metroTabPage1.Size = new System.Drawing.Size(521, 373);
            this.metroTabPage1.TabIndex = 0;
            this.metroTabPage1.Text = "Call Phone";
            this.metroTabPage1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabPage1.VerticalScrollbarBarColor = true;
            this.metroTabPage1.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.VerticalScrollbarSize = 10;
            // 
            // button14
            // 
            this.button14.ActiveControl = null;
            this.button14.Location = new System.Drawing.Point(145, 294);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(210, 37);
            this.button14.Style = MetroFramework.MetroColorStyle.Silver;
            this.button14.TabIndex = 17;
            this.button14.Text = "Call";
            this.button14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button14.UseSelectable = true;
            // 
            // button10
            // 
            this.button10.ActiveControl = null;
            this.button10.Location = new System.Drawing.Point(253, 252);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(48, 37);
            this.button10.Style = MetroFramework.MetroColorStyle.Silver;
            this.button10.TabIndex = 16;
            this.button10.Text = "#";
            this.button10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button10.UseSelectable = true;
            // 
            // button11
            // 
            this.button11.ActiveControl = null;
            this.button11.Location = new System.Drawing.Point(199, 252);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(48, 37);
            this.button11.Style = MetroFramework.MetroColorStyle.Silver;
            this.button11.TabIndex = 15;
            this.button11.Text = "0";
            this.button11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button11.UseSelectable = true;
            // 
            // button12
            // 
            this.button12.ActiveControl = null;
            this.button12.Location = new System.Drawing.Point(145, 252);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(48, 37);
            this.button12.Style = MetroFramework.MetroColorStyle.Silver;
            this.button12.TabIndex = 14;
            this.button12.Text = "*";
            this.button12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button12.UseSelectable = true;
            // 
            // button7
            // 
            this.button7.ActiveControl = null;
            this.button7.Location = new System.Drawing.Point(253, 209);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(48, 37);
            this.button7.Style = MetroFramework.MetroColorStyle.Silver;
            this.button7.TabIndex = 13;
            this.button7.Text = "9";
            this.button7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button7.UseSelectable = true;
            // 
            // button8
            // 
            this.button8.ActiveControl = null;
            this.button8.Location = new System.Drawing.Point(199, 209);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(48, 37);
            this.button8.Style = MetroFramework.MetroColorStyle.Silver;
            this.button8.TabIndex = 12;
            this.button8.Text = "8";
            this.button8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button8.UseSelectable = true;
            // 
            // button9
            // 
            this.button9.ActiveControl = null;
            this.button9.Location = new System.Drawing.Point(145, 209);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(48, 37);
            this.button9.Style = MetroFramework.MetroColorStyle.Silver;
            this.button9.TabIndex = 11;
            this.button9.Text = "7";
            this.button9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button9.UseSelectable = true;
            // 
            // button4
            // 
            this.button4.ActiveControl = null;
            this.button4.Location = new System.Drawing.Point(253, 166);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(48, 37);
            this.button4.Style = MetroFramework.MetroColorStyle.Silver;
            this.button4.TabIndex = 10;
            this.button4.Text = "6";
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button4.UseSelectable = true;
            // 
            // button5
            // 
            this.button5.ActiveControl = null;
            this.button5.Location = new System.Drawing.Point(199, 166);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(48, 37);
            this.button5.Style = MetroFramework.MetroColorStyle.Silver;
            this.button5.TabIndex = 9;
            this.button5.Text = "5";
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button5.UseSelectable = true;
            // 
            // button6
            // 
            this.button6.ActiveControl = null;
            this.button6.Location = new System.Drawing.Point(145, 166);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(48, 37);
            this.button6.Style = MetroFramework.MetroColorStyle.Silver;
            this.button6.TabIndex = 8;
            this.button6.Text = "4";
            this.button6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button6.UseSelectable = true;
            // 
            // button3
            // 
            this.button3.ActiveControl = null;
            this.button3.Location = new System.Drawing.Point(253, 123);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(48, 37);
            this.button3.Style = MetroFramework.MetroColorStyle.Silver;
            this.button3.TabIndex = 7;
            this.button3.Text = "3";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button3.UseSelectable = true;
            // 
            // button2
            // 
            this.button2.ActiveControl = null;
            this.button2.Location = new System.Drawing.Point(199, 123);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(48, 37);
            this.button2.Style = MetroFramework.MetroColorStyle.Silver;
            this.button2.TabIndex = 6;
            this.button2.Text = "2";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button2.UseSelectable = true;
            // 
            // button1
            // 
            this.button1.ActiveControl = null;
            this.button1.Location = new System.Drawing.Point(145, 123);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(48, 37);
            this.button1.Style = MetroFramework.MetroColorStyle.Silver;
            this.button1.TabIndex = 5;
            this.button1.Text = "1";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button1.UseSelectable = true;
            // 
            // button13
            // 
            this.button13.ActiveControl = null;
            this.button13.Location = new System.Drawing.Point(307, 123);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(48, 165);
            this.button13.Style = MetroFramework.MetroColorStyle.Silver;
            this.button13.TabIndex = 4;
            this.button13.Text = "<=";
            this.button13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button13.UseSelectable = true;
            // 
            // textBox1
            // 
            // 
            // 
            // 
            this.textBox1.CustomButton.Image = null;
            this.textBox1.CustomButton.Location = new System.Drawing.Point(261, 1);
            this.textBox1.CustomButton.Name = "";
            this.textBox1.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.textBox1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.textBox1.CustomButton.TabIndex = 1;
            this.textBox1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.textBox1.CustomButton.UseSelectable = true;
            this.textBox1.CustomButton.Visible = false;
            this.textBox1.Lines = new string[0];
            this.textBox1.Location = new System.Drawing.Point(109, 70);
            this.textBox1.MaxLength = 32767;
            this.textBox1.Name = "textBox1";
            this.textBox1.PasswordChar = '\0';
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBox1.SelectedText = "";
            this.textBox1.SelectionLength = 0;
            this.textBox1.SelectionStart = 0;
            this.textBox1.ShortcutsEnabled = true;
            this.textBox1.Size = new System.Drawing.Size(283, 23);
            this.textBox1.TabIndex = 3;
            this.textBox1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.textBox1.UseSelectable = true;
            this.textBox1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.textBox1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(109, 48);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(58, 19);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "Number";
            this.metroLabel1.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.Controls.Add(this.metroLabel4);
            this.metroTabPage2.Controls.Add(this.button15);
            this.metroTabPage2.Controls.Add(this.textBox3);
            this.metroTabPage2.Controls.Add(this.metroLabel3);
            this.metroTabPage2.Controls.Add(this.textBox2);
            this.metroTabPage2.Controls.Add(this.metroLabel2);
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.HorizontalScrollbarSize = 10;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(521, 373);
            this.metroTabPage2.TabIndex = 1;
            this.metroTabPage2.Text = "Send SMS";
            this.metroTabPage2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            this.metroTabPage2.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.VerticalScrollbarSize = 10;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(77, 338);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(46, 19);
            this.metroLabel4.TabIndex = 9;
            this.metroLabel4.Text = "Status:";
            this.metroLabel4.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // button15
            // 
            this.button15.ActiveControl = null;
            this.button15.Location = new System.Drawing.Point(77, 282);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(375, 41);
            this.button15.Style = MetroFramework.MetroColorStyle.Silver;
            this.button15.TabIndex = 8;
            this.button15.Text = "Send";
            this.button15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button15.UseSelectable = true;
            // 
            // textBox3
            // 
            // 
            // 
            // 
            this.textBox3.CustomButton.Image = null;
            this.textBox3.CustomButton.Location = new System.Drawing.Point(197, 1);
            this.textBox3.CustomButton.Name = "";
            this.textBox3.CustomButton.Size = new System.Drawing.Size(177, 177);
            this.textBox3.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.textBox3.CustomButton.TabIndex = 1;
            this.textBox3.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.textBox3.CustomButton.UseSelectable = true;
            this.textBox3.CustomButton.Visible = false;
            this.textBox3.Lines = new string[] {
        "I want to say that I hate you."};
            this.textBox3.Location = new System.Drawing.Point(77, 97);
            this.textBox3.MaxLength = 32767;
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.PasswordChar = '\0';
            this.textBox3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBox3.SelectedText = "";
            this.textBox3.SelectionLength = 0;
            this.textBox3.SelectionStart = 0;
            this.textBox3.ShortcutsEnabled = true;
            this.textBox3.Size = new System.Drawing.Size(375, 179);
            this.textBox3.TabIndex = 7;
            this.textBox3.Text = "I want to say that I hate you.";
            this.textBox3.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.textBox3.UseSelectable = true;
            this.textBox3.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.textBox3.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(77, 76);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(126, 19);
            this.metroLabel3.TabIndex = 6;
            this.metroLabel3.Text = "Content of Message";
            this.metroLabel3.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // textBox2
            // 
            // 
            // 
            // 
            this.textBox2.CustomButton.Image = null;
            this.textBox2.CustomButton.Location = new System.Drawing.Point(353, 1);
            this.textBox2.CustomButton.Name = "";
            this.textBox2.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.textBox2.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.textBox2.CustomButton.TabIndex = 1;
            this.textBox2.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.textBox2.CustomButton.UseSelectable = true;
            this.textBox2.CustomButton.Visible = false;
            this.textBox2.Lines = new string[0];
            this.textBox2.Location = new System.Drawing.Point(77, 50);
            this.textBox2.MaxLength = 32767;
            this.textBox2.Name = "textBox2";
            this.textBox2.PasswordChar = '\0';
            this.textBox2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.textBox2.SelectedText = "";
            this.textBox2.SelectionLength = 0;
            this.textBox2.SelectionStart = 0;
            this.textBox2.ShortcutsEnabled = true;
            this.textBox2.Size = new System.Drawing.Size(375, 23);
            this.textBox2.TabIndex = 5;
            this.textBox2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.textBox2.UseSelectable = true;
            this.textBox2.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.textBox2.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(77, 29);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(58, 19);
            this.metroLabel2.TabIndex = 4;
            this.metroLabel2.Text = "Number";
            this.metroLabel2.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroTabPage3
            // 
            this.metroTabPage3.Controls.Add(this.textBox4);
            this.metroTabPage3.Controls.Add(this.button17);
            this.metroTabPage3.Controls.Add(this.button16);
            this.metroTabPage3.HorizontalScrollbarBarColor = true;
            this.metroTabPage3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.HorizontalScrollbarSize = 10;
            this.metroTabPage3.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage3.Name = "metroTabPage3";
            this.metroTabPage3.Size = new System.Drawing.Size(521, 373);
            this.metroTabPage3.TabIndex = 2;
            this.metroTabPage3.Text = "Clipboard";
            this.metroTabPage3.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabPage3.VerticalScrollbarBarColor = true;
            this.metroTabPage3.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.VerticalScrollbarSize = 10;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.textBox4.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.textBox4.Location = new System.Drawing.Point(0, 0);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(521, 312);
            this.textBox4.TabIndex = 11;
            this.textBox4.Text = "";
            this.textBox4.LinkClicked += new System.Windows.Forms.LinkClickedEventHandler(this.textBox4_LinkClicked);
            // 
            // button17
            // 
            this.button17.ActiveControl = null;
            this.button17.Location = new System.Drawing.Point(435, 318);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(84, 44);
            this.button17.Style = MetroFramework.MetroColorStyle.Silver;
            this.button17.TabIndex = 10;
            this.button17.Text = "GET";
            this.button17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button17.UseSelectable = true;
            // 
            // button16
            // 
            this.button16.ActiveControl = null;
            this.button16.Location = new System.Drawing.Point(3, 318);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(84, 44);
            this.button16.Style = MetroFramework.MetroColorStyle.Silver;
            this.button16.TabIndex = 9;
            this.button16.Text = "SET";
            this.button16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button16.UseSelectable = true;
            // 
            // metroTabPage4
            // 
            this.metroTabPage4.Controls.Add(this.label4);
            this.metroTabPage4.Controls.Add(this.button19);
            this.metroTabPage4.Controls.Add(this.button20);
            this.metroTabPage4.Controls.Add(this.button18);
            this.metroTabPage4.Controls.Add(this.pictureBox1);
            this.metroTabPage4.HorizontalScrollbarBarColor = true;
            this.metroTabPage4.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage4.HorizontalScrollbarSize = 10;
            this.metroTabPage4.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage4.Name = "metroTabPage4";
            this.metroTabPage4.Size = new System.Drawing.Size(521, 373);
            this.metroTabPage4.TabIndex = 3;
            this.metroTabPage4.Text = "Wallpaper";
            this.metroTabPage4.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabPage4.VerticalScrollbarBarColor = true;
            this.metroTabPage4.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage4.VerticalScrollbarSize = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 321);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 19);
            this.label4.TabIndex = 13;
            this.label4.Text = "...";
            this.label4.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // button19
            // 
            this.button19.ActiveControl = null;
            this.button19.Location = new System.Drawing.Point(304, 330);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(84, 44);
            this.button19.Style = MetroFramework.MetroColorStyle.Silver;
            this.button19.TabIndex = 12;
            this.button19.Text = "Get";
            this.button19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button19.UseSelectable = true;
            // 
            // button20
            // 
            this.button20.ActiveControl = null;
            this.button20.Location = new System.Drawing.Point(214, 330);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(84, 44);
            this.button20.Style = MetroFramework.MetroColorStyle.Silver;
            this.button20.TabIndex = 11;
            this.button20.Text = "Set";
            this.button20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button20.UseSelectable = true;
            // 
            // button18
            // 
            this.button18.ActiveControl = null;
            this.button18.Location = new System.Drawing.Point(124, 330);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(84, 44);
            this.button18.Style = MetroFramework.MetroColorStyle.Silver;
            this.button18.TabIndex = 10;
            this.button18.Text = "Save";
            this.button18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button18.UseSelectable = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(521, 301);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // Telefon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(569, 495);
            this.Controls.Add(this.metroTabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Telefon";
            this.Text = "Phone";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabControl1.ResumeLayout(false);
            this.metroTabPage1.ResumeLayout(false);
            this.metroTabPage1.PerformLayout();
            this.metroTabPage2.ResumeLayout(false);
            this.metroTabPage2.PerformLayout();
            this.metroTabPage3.ResumeLayout(false);
            this.metroTabPage4.ResumeLayout(false);
            this.metroTabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private MetroFramework.Controls.MetroTabPage metroTabPage1;
        private MetroFramework.Controls.MetroTabPage metroTabPage2;
        private MetroFramework.Controls.MetroTabPage metroTabPage3;
        private MetroFramework.Controls.MetroTabPage metroTabPage4;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox textBox1;
        private MetroFramework.Controls.MetroTile button13;
        private MetroFramework.Controls.MetroTile button1;
        private MetroFramework.Controls.MetroTile button3;
        private MetroFramework.Controls.MetroTile button2;
        private MetroFramework.Controls.MetroTile button7;
        private MetroFramework.Controls.MetroTile button8;
        private MetroFramework.Controls.MetroTile button9;
        private MetroFramework.Controls.MetroTile button4;
        private MetroFramework.Controls.MetroTile button5;
        private MetroFramework.Controls.MetroTile button6;
        private MetroFramework.Controls.MetroTile button10;
        private MetroFramework.Controls.MetroTile button11;
        private MetroFramework.Controls.MetroTile button12;
        private MetroFramework.Controls.MetroTile button14;
        private MetroFramework.Controls.MetroTextBox textBox3;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTextBox textBox2;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroTile button16;
        private MetroFramework.Controls.MetroTile button17;
        private MetroFramework.Controls.MetroTile button19;
        private MetroFramework.Controls.MetroTile button20;
        private MetroFramework.Controls.MetroTile button18;
        public MetroFramework.Controls.MetroLabel label4;
        public System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.RichTextBox textBox4;
        public MetroFramework.Controls.MetroLabel metroLabel4;
        public MetroFramework.Controls.MetroTile button15;
    }
}